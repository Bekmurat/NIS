/**
 *  ==================================================
 *  SoftChalk LessonBuilder
 *  Activity activity_info.js
 *  Copyright 2008 SoftChalk LLC
 *  All Rights Reserved.
 *
 *  http://www.softchalk.com
 *  ==================================================
 */

q_done_a=new Array();
scoreQa=new Array();
score_a=new Array();
show_restart_a=new Array();
num_pages=5;
actOrder=new Array(5);
actOrder[0]=1;
actOrder[1]=2;
actOrder[2]=8;
actOrder[3]=3;
actOrder[4]=4;

//a_num=1;
a_value1=3;
scoreQa[1]=true;
q_done_a[1]=false;
score_a[1]=0;
show_restart_a[1]=true;

//a_num=2;
a_value2=12;
scoreQa[2]=true;
q_done_a[2]=false;
score_a[2]=0;
show_restart_a[2]=true;

//a_num=8;
a_value8=6;
scoreQa[8]=true;
q_done_a[8]=false;
score_a[8]=0;
show_restart_a[8]=true;

//a_num=3;
a_value3=8;
scoreQa[3]=true;
q_done_a[3]=false;
score_a[3]=0;
show_restart_a[3]=true;

//a_num=4;
a_value4=9;
scoreQa[4]=true;
q_done_a[4]=false;
score_a[4]=0;
show_restart_a[4]=true;

