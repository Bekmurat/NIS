/**
 *  ==================================================
 *  SoftChalk LessonBuilder q_parameters.js
 *  Copyright 2003-2010 SoftChalk LLC
 *  All Rights Reserved.
 *
 *  http://www.softchalk.com
 *  ==================================================
 */

q_item=2;
group_item=0;
tableToggle_array=new Array();
f_done=new Array();
feed=new Array();
q_done=new Array();
scoreQ=new Array();
qOrder=new Array();
qOrder[0]=1;
qOrder[1]=2;
num_pages=5;
scorm_completed_status=true;

//q_num=1;
inline_feedback1=true;
q_done[1]=false;
q_value1=5;
scoreQ[1]="yes";
mc_items1=2;
//ra_items1=1;
q_type1=2;
theQuestion1="Linguistics involves the study of fruits and vegetables.";
showCorrect1="yes";
showHint1="no";
case_sensitive1="false";
partial_credit1=false;
feedbackRight1="Right! Good job!";
feedbackWrong1="Sorry, incorrect answer.";
feedbackPartial1="Partially correct.";
hint1="";
right_answers1=new Array(1);
right_answers1[0]="false";
answer_choices1=new Array(2);
answer_choices1[0]="True";
answer_choices1[1]="False";
tableToggle_array[1]=true;
f_done[1]=false;
feed[1]=false;
//colorChoice1="_custom";
//tableClass1="expand";
//openerImage1="none.gif";
//allowRetry1=true;
//groupID1=0;

//q_num=2;
inline_feedback2=true;
q_done[2]=false;
q_value2=5;
scoreQ[2]="yes";
mc_items2=3;
//ra_items2=1;
q_type2=1;
theQuestion2="The vowel sound in &quot;bed&quot; is...";
showCorrect2="yes";
showHint2="no";
case_sensitive2="false";
partial_credit2=false;
feedbackRight2="Right! Good job!";
feedbackWrong2="Sorry, incorrect answer.";
feedbackPartial2="Partially correct.";
hint2="";
right_answers2=new Array(1);
right_answers2[0]="a";
answer_choices2=new Array(3);
answer_choices2[0]="&nbsp;&#603;";
answer_choices2[1]="&#230;";
answer_choices2[2]="&#601;";
tableToggle_array[2]=true;
f_done[2]=false;
feed[2]=false;
//colorChoice2="_custom";
//tableClass2="expand";
//openerImage2="selfcheck_custom.gif";
//allowRetry2=true;
//groupID2=0;

